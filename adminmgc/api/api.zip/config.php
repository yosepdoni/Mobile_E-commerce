<?php
class Database
{

    private $db_host = 'localhost';
    private $db_name = 'id19718264_dbmgc';
    private $db_username = 'id19718264_mgc';
    private $db_password = 'Mgc_16_03_2023';


    public function dbConnection()
    {

        try {
            $conn = new PDO('mysql:host=' . $this->db_host . ';dbname=' . $this->db_name, $this->db_username, $this->db_password);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        } catch (PDOException $e) {
            echo "Connection error " . $e->getMessage();
            exit;
        }
    }
}