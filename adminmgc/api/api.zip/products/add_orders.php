<?php
require '../config.php';

class OrdersAPI
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function addOrder($user_id, $product_id, $products, $category, $qty, $payment, $bukti_pay, $tgl)
    {
        $query = "INSERT INTO orders (user_id, product_id, products, category, qty, payment, bukti_pay, tgl) 
                  VALUES (:user_id, :product_id, :products, :category, :qty, :payment, :bukti_pay, :tgl)";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(":user_id", $user_id);
        $stmt->bindParam(":product_id", $product_id);
        $stmt->bindParam(":products", $products);
        $stmt->bindParam(":category", $category);
        $stmt->bindParam(":qty", $qty);
        $stmt->bindParam(":payment", $payment);
        $stmt->bindParam(":bukti_pay", $bukti_pay);
        $stmt->bindParam(":tgl", $tgl, PDO::PARAM_STR); // Specify the parameter type as string

        if ($stmt->execute()) {
            $order_id = $this->db->lastInsertId();
            return $order_id;
        } else {
            return false;
        }
    }
}

// Menggunakan koneksi database yang sudah ada
$database = new Database();
$db = $database->dbConnection();

// Membuat instance API Orders
$ordersAPI = new OrdersAPI($db);

// Mendapatkan data yang diperlukan dari request
$data = json_decode(file_get_contents('php://input'), true);

$user_id = isset($data['user_id']) ? $data['user_id'] : null;
$product_id = isset($data['product_id']) ? $data['product_id'] : null;
$products = isset($data['products']) ? $data['products'] : null;
$category = isset($data['category']) ? $data['category'] : null;
$qty = isset($data['qty']) ? $data['qty'] : null;
$payment = isset($data['payment']) ? $data['payment'] : null;
$bukti_pay = isset($data['bukti_pay']) ? $data['bukti_pay'] : null;
$tgl = isset($data['tgl']) ? date('Y-m-d', strtotime($data['tgl'])) : null; // Format the date correctly

// Memanggil fungsi addOrder()
if ($user_id && $product_id && $products && $category && $qty && $payment && $bukti_pay && $tgl) {
    $order_id = $ordersAPI->addOrder($user_id, $product_id, $products, $category, $qty, $payment, $bukti_pay, $tgl);

    if ($order_id) {
        $response = array(
            'success' => true,
            'message' => 'Order added successfully.',
            'order_id' => $order_id
        );
    } else {
        $response = array(
            'success' => false,
            'message' => 'Failed to add order.'
        );
    }
} else {
    $response = array(
        'success' => false,
        'message' => 'Invalid data.'
    );
}

// Menampilkan hasil dalam format JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
